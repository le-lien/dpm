# dpm 
Project initialied in August 2018 with Prof. Mansmann
Dynamic prediction model applying MCMC
Shiny app with 3 main functions: 1) simulation of data with repeated measurements, 2) dynamic prediction of future outcome, 3) visualize the results


Command for version control
packrat::init("~/applications/my-shiny-app") 
packrat::snapshot()
packrat::bundle()

Command to call app from github
shiny::runGitHub( "dpm", "le-lien") 
